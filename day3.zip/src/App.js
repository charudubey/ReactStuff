import React, { Component } from 'react';
import logo from './logo.svg';
import $ from 'jquery';
import './App.css';

class App extends Component {

  constructor(props){
    console.log("constructor called");
    super(props);
    this.state={
      todos:[]
    }
  }

  componentDidMount(){
        $.ajax({
          url:'https://jsonplaceholder.typicode.com/todos',
          success:(data) => {
            this.setState({
              todos:data
            })
          }
        })
    }

  render() {
    return (
      <div>
        <h1>Ajax Demo</h1>
        <hr/>
        <ul>
          {
          this.state.todos.map((todo) => {
            return <li>{todo.title} | {todo.id}</li>
          })
          }
        </ul>
      </div>
    );
  }
}

export default App;
