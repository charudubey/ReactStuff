import React from 'react';

export default class LifeCycleDemoComponent extends React.Component{

    constructor(){
        super();
        console.log("Constructor called");
    }

    componentWillMount(){
        console.log("Component Will Mount called");
    }

    componentDidMount(){
        console.log("Component Did Mount called");
    }

    render(){
        console.log("Render Called");
        return(
            <h1>Life Cycle Demo</h1>
        )
    }
        
}