import React, { Component } from 'react';
import './App.css';
import ProfilePhotoComponent from './ProfilePhotoComponent';
import NameComponent from './NameComponent'
import UsernameComponent from './UsernameComponent'


const BadgeComponent = (props) =>{
    return (
        <div className="issueComponent">
            <ProfilePhotoComponent imgsrc={props.userinfo.src}/>
            <NameComponent name={props.userinfo.name}/>
            <UsernameComponent username={props.userinfo.username}/>
        </div>
    );
}

export default BadgeComponent;
