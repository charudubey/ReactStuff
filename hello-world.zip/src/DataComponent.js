import React, { Component } from 'react';

class DataComponent extends Component {
  render() {
    return (
        <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Task</th>
            <th>AssignedBy</th>
            <th>Status</th>
            <th>Operation</th>
        </tr>
        <tr>
            <td>101</td>
            <td>Nikhil</td>
            <td>React</td>
            <td>Pankaj Sharma</td>
            <td>In Progess</td>
            <td>project</td>
        </tr>
        <tr>
            <td>102</td>
            <td>Vishal</td>
            <td>React</td>
            <td>Pankaj Sharma</td>
            <td>In Progess</td>
            <td>project</td>
        </tr>
        </table>
    );
  }
    
}

export default DataComponent;