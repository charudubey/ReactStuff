import React, { Component } from 'react';
import Logo from './Logo'
import MenuBar from './MenuBar'

class HeaderComponent extends Component {
  render() {
    return (
      <div>
        <Logo/>
        <MenuBar/>
      </div>
    );
  }
    
}

export default HeaderComponent;