import React, { Component } from 'react';
import './App.css';
import HeaderComponent from './HeaderComponent';
import SearchComponent from './SearchComponent';
import DataComponent from './DataComponent';

const IssueOne = () =>{
    return (
        <div className="issueComponent">
       <HeaderComponent/>
        <SearchComponent/>
        <DataComponent />
      </div>
    );
}

export default IssueOne;
