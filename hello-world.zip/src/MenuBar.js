import React, { Component } from 'react';

class MenuBar extends Component {
  render() {
    return (
        <h3>Home | About Us | Contact Us</h3>
    );
  }
    
}

export default MenuBar;