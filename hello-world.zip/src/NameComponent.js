import React, { Component } from 'react';

class NameComponent extends Component {
  render() {
    return (
        <h3>Name: {this.props.name}</h3>
    );
  }
    
}

export default NameComponent;