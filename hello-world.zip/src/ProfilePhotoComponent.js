import React, { Component } from 'react';

class ProfilePhotoComponent extends Component {
  render() {
    return (
        <img src={this.props.imgsrc} className="Photo-logo" alt="src" />
    );
  }
    
}

export default ProfilePhotoComponent;