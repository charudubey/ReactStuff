import React, { Component } from 'react';

class SearchComponent extends Component {
  render() {
    return (
        <div><input type="text" /><input type="button" value="Search" /></div>
    );
  }
    
}

export default SearchComponent;