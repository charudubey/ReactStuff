import React from 'react';

class ShowActiveUser extends React.Component{
    render(){
        return (
            <ul>
            {
                this.props.userList.filter(function(user){
                    return user.status === 1;  
                }).map(function(u){
                    return (<li>{u.name}</li>);
                })
                
            }
            </ul>
        );
    }
}

export default ShowActiveUser;