import React from 'react';

const ShowTaskList = (props) =>{
    return (
        
        <ul>
        {
            /*props.taskList.map(task => (
                <li>{task}</li>
            ))*/
            
            props.taskList.map(function(task){
                return (<li>{task}</li>);
            })
        
        }
        </ul>
    );
}

export default ShowTaskList;