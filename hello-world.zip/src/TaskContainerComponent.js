import React, { Component } from 'react';
import ShowTaskList from './ShowTaskList';

class TaskContainerComponent extends Component {
    
  render() {
    var userName = "Pankaj Sharma";
    var tasks = ['Creating React POC', 'Working on Project', 'Attending Meeting'];
    return (
        <div>
            Task Created By: {userName}
            <hr/>
            <ShowTaskList taskList = {tasks}/>
        </div>
    );
  }
    
}

export default TaskContainerComponent;