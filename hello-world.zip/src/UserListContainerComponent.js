import React, { Component } from 'react';
import ShowActiveUser from './ShowActiveUser';

class UserListContainerComponent extends Component {
    
  render() {
    var userList = [
        {name:'Yash',status:1},
        {name:'Vishal',status:1},
        {name:'Ruchi',status:2},
        {name:'Nitish',status:1},
        {name:'Kartik',status:2}
    ];
    return (
        <div>
            <h1>Filtered Active Users: </h1>
            <ShowActiveUser userList = {userList}/>
        </div>
    );
  }
    
}

export default UserListContainerComponent;