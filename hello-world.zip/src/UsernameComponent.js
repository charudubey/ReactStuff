import React, { Component } from 'react';

class UsernameComponent extends Component {
  render() {
    return (
        <h3>Username: {this.props.username}</h3>
    );
  }
    
}

export default UsernameComponent;