import React, { Component } from 'react';
// import logo from './logo.svg';
import IssueListComponent from './component/IssueListComponent';
import './App.css';

class App extends Component {
  render() {
    return (
      <IssueListComponent/>
    );
  }
}

export default App;
