import React from 'react';

class HeaderComponent extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            headerText:"Yash Issue Tracker App",
            logo: "YITS"
        }
    }
    
    render(){
        return(
            <div>
            {this.state.logo}
            <h1>{this.state.headerText}</h1>
            </div>
        )
    }
}

export default HeaderComponent;