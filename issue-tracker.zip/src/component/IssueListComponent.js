import React from 'react';
import IssueNameComponent from './IssueNameComponent';
import IssueForm from './IssueForm';

class IssueListComponent extends React.Component{
    constructor(props){
        super(props);
        this.changeStatus = this.changeStatus.bind(this);
        this.updateIssue = this.updateIssue.bind(this);
        this.addIssue = this.addIssue.bind(this);
        this.deleteIssue = this.deleteIssue.bind(this);
        this.state = {
            issues:[{name:"Create React App",completed:false},
                    {name:"Create React POC",completed:false},
                    {name:"Create Rest App",completed:false}],
            currentIssue:''
        }
    } 
    changeStatus(index){
        var issues = this.state.issues;
        var issue = issues[index];
        issue.completed = !issue.completed; 
        this.setState(
            {
                issues
            }
        );
        console.log(this.state.issues[index]);
    }

    addIssue(event){
        event.preventDefault();
        let issues = this.state.issues;
        let currentIssue = this.state.currentIssue;
        issues.push({
            name:currentIssue,
            completed:false
        })
        this.setState({
            issues:issues,
            currentIssue:''
        })
        console.log("  ADD ISSUE  ");
    }

    deleteIssue(issueToBeDeleted){
        console.log("  Delete ISSUE  ");
        let issues = this.state.issues;
        issues.splice(issueToBeDeleted,1);
        this.setState({
            issues:issues
        })
    }

    updateIssue(newValue){
        this.setState({
            currentIssue:newValue.target.value
        })
    }
    render(){
        return(
            
                    <div>
                        <h1>Issue Tracker App</h1>
                        <hr/>
                        <section>
                            <IssueForm 
                                currentIssue={this.state.currentIssue} 
                                updateIssue={this.updateIssue}
                                addIssue={this.addIssue} 
                                />
                        </section>
                        <ul>
                        {
                                this.state.issues.map((issue,index) => {
                                return <IssueNameComponent 
                                    key={issue.name} 
                                    clickHandler={this.changeStatus}
                                    issue={issue}
                                    index={index}
                                    deleteIssue = {this.deleteIssue}/>
                                })
                            }
                        </ul>
                    </div>
                
        )
    }
}

export default IssueListComponent;