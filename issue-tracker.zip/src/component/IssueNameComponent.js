import React from 'react';

class IssueNameComponent extends React.Component{
   
    constructor(props){
        super(props);
        this.state = {
            isEditing:false
        }
    } 

    render(){
        return(
            <section>
                <form>
                    <input type="text" defaultValue={this.props.issue.name}/>
                    <button>update</button>
                </form>
            </section>
        )
    }
}

export default IssueNameComponent;