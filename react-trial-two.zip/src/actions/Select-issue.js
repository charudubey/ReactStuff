import React from 'react';

export const selectIssue = (issue) => {
    console.log("You clicked on select Issue", issue.task);
    return{
        type:'ISSUE_SELECTED',
        payload:issue
    }
};

export const addIssue = (issue) => {
    console.log("You clicked on add Issue", issue);
    return{
        type: 'ISSUE_ADD',
        payload:issue
    }
};

export const deleteIssue = (issue) => {
    console.log("You clicked on delete Issue", issue);
    return{
        type: 'ISSUE_DELETE',
        payload: issue
    }
};

export const updateIssue = (issue) => {
    console.log("You clicked on update Issue", issue);
    return{
        type: 'ISSUE_UPDATE',
        payload: issue
    }
};

export const fetchAllIssues = (issues) => {
    console.log("You clicked on fetch all Issues", issues);
    return{
        type: 'ISSUE_FETCH_ALL',
        payload: issues
    }
};
