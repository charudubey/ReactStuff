import React from 'react';

export const selectUser = (user) => {
    console.log("You clicked on select Users: ", users.name);
    return{
        type:'USER_SELECTED',
        payload:users
    }
};

export const addUser = (user) => {
    console.log("You clicked on add user: ", user);
    return{
        type: 'USER_ADD',
        payload:user
    }
};

export const deleteUser = (user) => {
    console.log("You clicked on delete user: ", user);
    return{
        type: 'USER_DELETE',
        payload: user
    }
};

export const updateUser = (user) => {
    console.log("You clicked on update User", user);
    return{
        type: 'USER_UPDATE',
        payload: user
    }
};

export const fetchAllUsers = (users) => {
    console.log("You clicked on fetch all Users", users);
    return{
        type: 'USER_FETCH_ALL',
        payload: users
    }
};
