import React from 'react';
import IssueList from '../containers/issue-list';
import IssueDetail from '../containers/issue-detail';

const App =() =>(
<div>
<h1>React-Redux -[IssueTracker -Demo]</h1>
<hr/>
<h2>Issue-List</h2>
<IssueList/>
<hr/>
<h2>Issue-Detail</h2>
<IssueDetail/>
</div>
);
export default App;