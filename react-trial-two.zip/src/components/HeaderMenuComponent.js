import React from 'react';
import '.././App.css';

export default class HeaderMenuComponent extends React.Component{
    render(){
        return(
            <div>
                <h1>
                    Shopping Cart
                </h1>
            </div>
        );
    }
}
