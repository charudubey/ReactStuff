import React from 'react';
import MenuComponent from './MenuComponent';

const Index =() =>(
<div>
    <h1>React-Redux -[Shopping Cart]</h1>
    <MenuComponent/>
</div>
);

export default Index;