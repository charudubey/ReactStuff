import React from 'react';

export default class SearchComponent extends React.Component{
    render(){
        return (
                    <div>
                        <input type="text" />
                        <button type="submit">Search</button>
                    </div>
                );
    }
}