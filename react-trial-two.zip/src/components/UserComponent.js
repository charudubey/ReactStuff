import React, { Component } from 'react';
import '.././App.css';

import HeaderMenuComponent from './HeaderMenuComponent';
import SearchComponent from './SearchComponent';
import AddNewUserComponent from './AddNewUserComponent';
import ClientDataComponent from './ClientDataComponent';


export default class UserComponent extends Component {
  render() {
    return (
    <div>
      <div className="row">
        <div className="col">
          <HeaderMenuComponent /> <br/>
        </div>
      </div>
      <div className="row">
        <div className="col">
          <AddNewUserComponent />
        </div>
        <div className="col">
          <SearchComponent /> <br/>
        </div>
        <div className="col">
          <ClientDataComponent />
        </div>
      </div>
    </div>  
    );
  }
}
