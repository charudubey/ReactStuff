import React,{Component} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';

class IssueDetail extends Component{
render(){
    if(!this.props.issue){
    return(<h1>Select issue....</h1>);
    }

    return(
        <div>
        <h3>ID : {this.props.issue.id}</h3>
        <h3>Task : {this.props.issue.task}</h3>
        <h3>Description : {this.props.issue.description}</h3>
        </div>
        );
    }
}

function mapStateToProps(state){
    return{
    issue:state.activeIssue
    }
}
export default connect(mapStateToProps)(IssueDetail);