import React,{Component} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {selectIssue} from '../actions/Select-issue';

class UserList extends Component{

    createUserList(){
        return this.props.users.map( (user) =>{
                return(
                <tr>
                    <td><input type="checkbox" name={user.id}/></td>
                    <td>{user.name}</td>
                    <td>{user.image}</td>
                    <td>{user.email}</td>
                    <td>{user.contact}</td>
                    <td>{user.status}</td>
                    <td>
                        <button type="button" name="edit">Edit</button> | 
                        <button type="button" name="delete">Delete</button>
                    </td>
                </tr>
                );
            });
        }

    render(){
        return(
                <div>
                    {this.createUserList}
                </div>
        );
    }
}

function mapStateToProps(state){
    return{
        users:state.users
    }
}

function matchDispatchToProps(dispatch){
    return bindActionCreators({selectUser: selectUser},dispatch)
}

export default connect(mapStateToProps, matchDispatchToProps)(UserList);