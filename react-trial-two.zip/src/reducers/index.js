import{combineReducers} from 'redux';
import IssueReducer from './reducer-issues';
import ActiveIssueReducer from './reducer-active-issue';
import ActiveUserReducer from './reducer-active-user';
import UserReducer from './reducer-users';

const allReducers=combineReducers({
    issues:IssueReducer,
    activeIssue:ActiveIssueReducer,
    users:UserReducer,
    activeUser:ActiveUserReducer
});

export default allReducers;