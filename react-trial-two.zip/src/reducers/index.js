import{combineReducers} from 'redux';
import IssueReducer from './reducer-issues';
import ActiveIssueReducer from './reducer-active-issue';

const allReducers=combineReducers({
    issues:IssueReducer,
    activeIssue:ActiveIssueReducer
});

export default allReducers;