export default function(state=null,action){
    switch(action.type){
        case "ISSUE_SELECTED":
            return action.payload;
        case "ISSUE_ADD":
            return action.payload;
        case "ISSUE_DELETE":
            return action.payload;
        case "ISSUE_UPDATE":
            return action.payload;
        case "ISSUE_FETCH_ALL":
            return action.payload;
    }
    return state;
}