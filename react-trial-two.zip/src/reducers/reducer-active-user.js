export default function(state=null,action){
    switch(action.type){
        case "USER_SELECTED":
            return action.payload;
        case "USER_ADD":
            return action.payload;
        case "USER_DELETE":
            return action.payload;
        case "USER_UPDATE":
            return action.payload;
        case "USER_FETCH_ALL":
            return action.payload;
    }
    return state;
}