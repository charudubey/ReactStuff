export default function(){
return[
{
id:1,
task:'Creating Redux App',
description:'Creating Redux App from begining'
},
{
id:2,
task:'OPT training',
description:'start planning for OPT training'
},
{
id:3,
task:'US travel',
description:'Initiate mail for US travel for OPT training'
},
{
id:4,
task:'US Visit',
description:'Moving to US for OPT Training'
}
]
}