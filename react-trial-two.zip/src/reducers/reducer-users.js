export default function(){
return[
        {
        id:1,
        name:'Aditi Sharma',
        image:'img.png',
        email:'aditi.sharma@gmail.com',
        contact:'9874563210',
        status:"Registered"
        },
        {
        id:2,
        name:'Aditya Sharma',
        image:'img.png',
        email:'aditya.sharma@gmail.com',
        contact:'9844563210',
        status:"Registered"
        }
    ]
}