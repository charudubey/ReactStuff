import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import MenuComponent from './components/MenuComponent';

class App extends Component {
  render() {
    return (
      <div className="row">
        <MenuComponent />
      </div>
    );
  }
}

export default App;
