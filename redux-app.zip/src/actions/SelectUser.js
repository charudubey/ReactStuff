import React from 'react';

export const SelectUser = (user) => {
    console.log("Select User called!");
    return{
        type:'USER_REGISTERED',
        payload:user
    }
}