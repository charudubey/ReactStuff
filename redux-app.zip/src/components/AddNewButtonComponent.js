import React from 'react';

export default class AddNewButtonComponent extends React.Component{
    render(){
        return(
            <button type="button">Add New </button>
        );
    }
}
