import React from 'react';
import UserList from '../containers/user-list'

export default class ClientDataComponent extends React.Component{
    render(){
        return(
            <div>
                <table className="table">
                    <thead>
                    <tr>
                        <th>Select</th>
                        <th>Name</th>
                        <th>Image</th>
                        <th>Email</th>
                        <th>Contact</th>
                        <th>Status</th>
                        <th>Operation</th>
                    </tr>
                        </thead>
                    <tbody>
                        <UserList/>
                    </tbody>
                </table>
            </div>
        );
    }
}
