import React from 'react';

const HomeComponent = () => (
    <h1>Welcome to Shopping Cart</h1>
)

export default HomeComponent;