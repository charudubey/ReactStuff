import React from 'react';
import {NavLink} from 'react-router-dom';
import '.././App.css';

const LinksComponent = () => (
    <div className="list-group">
        <NavLink className="list-group-item" exact activeClassName="active" to="/">Home</NavLink>
        <NavLink className="list-group-item" activeClassName="active" to="/user">User Management</NavLink>
        <NavLink className="list-group-item" activeClassName="active" to="/order">Order Management</NavLink>
        <NavLink className="list-group-item" activeClassName="active" to="/product">Product Management</NavLink>
    </div>
)

export default LinksComponent;