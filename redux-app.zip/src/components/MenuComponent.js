import React, { Component } from 'react';
import {BrowserRouter as Router,Route} from 'react-router-dom';
import LinksComponent from './LinksComponent';
import UserComponent from './UserComponent';
import ProductComponent from './ProductComponent';
import OrderComponent from './OrderComponent';
import HomeComponent from './HomeComponent';

export default class MenuComponent extends Component {
    render() {
        return (
            <Router>

                <div className="row">
                    <div className="col-sm-3">
                        <LinksComponent/>
                    </div>
                    <div className="col-sm-9">
                        <Route exact path="/" component={HomeComponent} />
                        <Route path="/user" component={UserComponent} />
                        <Route path="/order" component={OrderComponent} />
                        <Route path="/product" component={ProductComponent} />
                    </div>
                </div>
            </Router>
        )
    }
}