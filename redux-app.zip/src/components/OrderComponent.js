import React from 'react';

const OrderComponent = () => (
    <div className="row">
        <h1>Welcome to Order Management</h1>
    </div>
)

export default OrderComponent;