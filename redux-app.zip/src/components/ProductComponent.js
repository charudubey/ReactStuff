import React from 'react';

const ProductComponent = () => (
    <div className="row">
        <h1>Welcome to Product Management</h1>
    </div>
)

export default ProductComponent;