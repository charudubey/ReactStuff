import React, { Component } from 'react';
import '.././App.css';

import HeaderMenuComponent from './HeaderMenuComponent';
import SearchButtonComponent from './SearchButtonComponent';
import AddNewButtonComponent from './AddNewButtonComponent';
import ClientDataComponent from './ClientDataComponent';


export default class UserComponent extends Component {
  render() {
    return (
    <div>
      <div className="row">
        <div className="col">
          <HeaderMenuComponent /> <br/>
        </div>
      </div>
      <div className="row">
        <div className="col">
          <AddNewButtonComponent />
        </div>
        <div className="col">
          <SearchButtonComponent /> <br/>
        </div>
        <div className="col">
          <ClientDataComponent />
        </div>
      </div>
    </div>  
    );
  }
}
