import React from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';

class UserList extends React.Component{

    createUserList(){
        return this.props.users.map( user => {
            return(
                <tr>
                    <td><input type="checkbox" name="{user.id}"/></td>
                    <td>{user.name}</td>
                    <td>{user.image}</td>
                    <td>{user.email}</td>
                    <td>{user.contact}</td>
                    <td>{user.status}</td>
                    <td>Edit | Delete</td>
                </tr>
            )
        })
    }

    render(){
        return (
            <UserList/>
        );
    }
}

function mapStateToProps(state){
    return{
    users:state.users
    };
}
export default connect(mapStateToProps)(UserList);